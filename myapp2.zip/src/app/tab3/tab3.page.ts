import { Component } from '@angular/core';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  title = '關於我';
  author = 'Tseng YI';
  filename = "au.png";
  lucky = 3;
  motto = "今日事,今日畢"
  aboutme = {
    name: 'Eric',
    fnme: 'au.png',
    lucky: 87,
    motto: "今日事,今日畢"

  }
  constructor() { }

}
