import { Component } from '@angular/core';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  //屬性定義 屬性繫結
  title = '首頁';
  pages = 7;
  units = [
    '人文學院',
    '觀光休閒與運動學院',
    '管理學院',
    '財經學院',
    '資訊與商業智慧學院',
    '通識教育中心',
    '體育教育中心'
  ];

  constructor() { }
  //自訂方法1
  area(r: number) {
    var a = r * r * 3.14
  }
  //自訂方法2
  unitSelected(unit: string) {
    console.log('你選的項目是:', unit)
  }


}
