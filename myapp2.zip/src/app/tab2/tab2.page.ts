import { Component } from '@angular/core';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  title = 'Tab2標題名稱';
  courses = [
    { name: '手機程式設計', credit: 3, subject: '選修', desc: '行動app開發課程' },
    { name: '行動技術與應用', credit: 3, subject: '選修', desc: '科技最新發展趨勢介紹與體驗' },
    { name: '基礎程式設計', credit: 3, subject: '必修', desc: 'python程式語言介紹' }
  ];

  C = [
    {
      name: 'Eric',
      fnme: "a.png",
      lucky: 3
    },
    {},
    {}
  ];

  constructor() { }

}
